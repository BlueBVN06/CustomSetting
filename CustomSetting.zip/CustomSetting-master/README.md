### CustomSetting
This plugin adds a new setting page in game settings.

## How to use?
If you've already put the plugin in your server and restarted your server, follow these steps:
- Go to "plugin_data"
- Go to "Custom Settings"
- Go to "Setting.json"
You can now edit the messages and use it :)
